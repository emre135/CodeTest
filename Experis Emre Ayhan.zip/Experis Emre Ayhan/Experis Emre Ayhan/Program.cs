﻿
var busses = new List<int>()
{
    180, 141, 174, 143, 142, 175
};



Console.WriteLine(sortBusses(busses));


string sortBusses(List<int> busses)
{
    
    busses.Sort();

    var output = new List<string>()
    {
        "Following busses stop here:"
    };

    var groupedBusses = new List<int>();
    bool startGrouping = false;
    var count = 0;

    //141, 142, 143, 174, 175, 180

    for (int i = 0; i < busses.Count; i++)
    {
        //grupperar minst tre bussar
        if (startGrouping)
        {
            var lowest = groupedBusses.First().ToString();
            var highest = groupedBusses.Last().ToString();
            var group = lowest + " - " + highest;
            output.Add(group);
            
            groupedBusses.Clear();
            count = 0;
            startGrouping = false;

        }
        //Eftersom det är första bussen kollar denna om 2 bussar efter går att gruppera
        if (i == 0)
        {
            
            if (busses[i] - busses[i+1] == -1 && busses[i+1] - busses[i+2] == -1)
            {
                groupedBusses.Add(busses[i]);
                count++;
            }
            //lägg annars till singel buss i output list som kommer göras om till en enda string
            else
            {
                output.Add(busses[i].ToString());
            }
        }
        
        //Körs när den inte kontrollerar första bussen, då kan vi kolla så att förgående buss samt nästa buss har 1 i mellanskillnaden på bussnumret
        if (i > 0)
        {
            if (busses[i] - busses[i-1] == 1 && busses[i] - busses[i+1] == -1)
            {
               
                groupedBusses.Add(busses[i]);
                count++;
                
            }
            //om förgående buss skiljer sig med värde 1 och antal tidigare grupperbara bussar motsvarar minst 2, lägg till i groupedBusses samt börja gruppera
            else if (busses[i] - busses[i-1] == 1 && count > 1)
            {
                groupedBusses.Add(busses[i]);
                startGrouping = true;
            }
            //lägg annars till singel buss i output list som kommer göras om till en enda string
            else
            {
                output.Add(busses[i].ToString());
            }
        }
        
        
    }
    //resultatet returneras i en string
    var result = String.Join(" ", output.ToArray());
    return result;
}




















































// var nameList = new List<string>()
// {
//     "bob",
//     "booob",
//     "boooooobapalaxxxxios"
// };
//
//
// foreach (var name in nameList)
// {
//     Simplify(name);
// }
//
//
// void Simplify(string name)
//     {
//
//         var currentIndex = 0;
//         List<char> list = name.ToList();
//         var count = list.Count;
//         
//         
//
//         for (int i = 0; i < count-1; i++)
//         {
//             
//             var currentLetter = list[currentIndex];
//             var nextLetter = list[currentIndex+1];
//
//             if (currentLetter == nextLetter)
//             {
//                 list.Remove(currentLetter);
//             }
//             else
//             {
//                 currentIndex++;
//             }
//             
//         }
//         
//         name = new string(list.ToArray());
//         Console.WriteLine(name);
//
//     }
    